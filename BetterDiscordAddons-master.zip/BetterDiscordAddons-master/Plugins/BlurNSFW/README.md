# BlurNSFW - [Download](https://betterdiscord.app/Download?id=28)

Blurs images in NSFW channels until you hover over it.

![Demo](https://i.imgur.com/ydqXKFG.gifv)


## Coming Soon
 - Ability to add custom channels and DMs to the list to blur.

