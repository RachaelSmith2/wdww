# BlurNSFW Changelog

### 0.2.1

 - Rewrite to new lib

### 0.2.0

 - Rewrite using internals (should be more consistent)
 - Unblur/blur for play/pause of videos

### 0.1.9

 - Fix for some discord updates

### 0.1.8

 - Update some selectors

### 0.1.7

 - Connect to lib

### 0.1.6

 - Add update checking

### 0.1.5

 - New style of grabing react data

### 0.1.4

 - Add check for old style nfsw channels
 - Better CSS selectors
 - Add check to ensure it can be an NSFW channel
 - Add overflow: hidden; to parent

### 0.1.3

 - Just add classes once upon entering the channel
 - Remove unused variables
 - Smoothen transitions
 - Add video blurring

### 0.1.2

 - Add multiple image types

### 0.1.1

 - Add css variables to be able to adjust blur amount

### 0.1.0

 - Switch from doing css on mousenter to just adding class on hover

### 0.0.1

 - Initial version