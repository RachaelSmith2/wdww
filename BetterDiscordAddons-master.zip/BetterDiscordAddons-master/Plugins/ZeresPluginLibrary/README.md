# ZeresPluginLibrary - [Download](https://betterdiscord.app/Download?id=9)

Gives other plugins utility functions and the ability to emulate v2.

You can see the source and documentation over at [https://github.com/rauenzi/BDPluginLibrary](https://github.com/rauenzi/BDPluginLibrary)
