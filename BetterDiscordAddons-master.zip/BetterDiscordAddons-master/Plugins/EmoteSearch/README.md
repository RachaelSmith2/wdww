# Emote Search
Search through all emotes in BD with /es uremotesearch

![Demo]( https://thumbs.gfycat.com/BlackandwhiteLiquidDoctorfish-size_restricted.gif)

## Known Bugs and Issues
 - certain updates may break the popup
 - emotes will take a while to load first search
 - broken emotes that are in database might clutter up results (arguable feature)
