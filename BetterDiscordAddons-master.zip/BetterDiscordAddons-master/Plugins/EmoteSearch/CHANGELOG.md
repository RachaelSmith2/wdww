# Emote Search Changelog

### 1.1.1

- rewritten to new plugin format
- lots of code cleanup

### 1.2.2

- rewritten to not break as often on updates of class names

### 1.2.3

 - moved over completely to zerebos from cates repo
 
### 1.2.4

 - Fix selector splitting
