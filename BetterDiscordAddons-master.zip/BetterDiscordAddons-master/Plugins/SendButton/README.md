# SendButton - [Download](https://betterdiscord.app/Download?id=191)

Adds a send button to channels where you have the permission to send messages.

![Demo](https://i.imgur.com/VVj4lCP.gif)


