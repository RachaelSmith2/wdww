# SendButton Changelog

### 0.1.0

 - Rewrite to use new library.

### 0.0.5

 - Fix for textarea changes

### 0.0.4

 - Fixed selector

### 0.0.3

 - Fixed CSS
 - Fixed trying to add button without form

### 0.0.2

 - Adjust the css and html for the send button
 - Remove most jQuery dependence
 - Add to all relevant textareas
 - Connected to lib

### 0.0.1

 - Initial release