# Discontinued

This was merged directly into BD itself and is no longer needed.

# RemoveMinimumSize

Removes the minimum window size forced by Discord.



