# ImageToClipboard

Allows you to copy images (png/jpg) directly to your system clipboard.


## Modals

![Modals](https://i.imgur.com/fsxpag2.png)

## Context Menu

![Context](https://i.imgur.com/fHt0zJg.png)


