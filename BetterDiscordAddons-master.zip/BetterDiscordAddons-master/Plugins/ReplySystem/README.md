# [Discontinued] ReplySystem

This plugin has been discontinued in favor of BetterReplyer by Zerthox because the main features of this have been integrated into Discord. See https://github.com/Zerthox/BetterDiscord-Plugins

