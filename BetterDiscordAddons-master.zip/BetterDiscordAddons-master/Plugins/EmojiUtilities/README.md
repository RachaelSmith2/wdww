# EmojiUtilities - [Download](https://betterdiscord.app/Download?id=187)

Allows you to blacklist and favorite emojis through the context menu. Favorites show up as a section in the emoji picker and all emojis in the picker get a context menu to blacklist or favorite them.


