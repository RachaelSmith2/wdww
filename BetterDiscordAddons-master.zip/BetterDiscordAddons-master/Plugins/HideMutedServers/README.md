# HideMutedServers - [Download](https://betterdiscord.app/Download?id=194)

Hides muted servers with a context menu option to show/hide. Acts similar to Discord's Hide Muted Channels option.

## Preview

![Preview](https://i.imgur.com/zjSkKuX.png)


