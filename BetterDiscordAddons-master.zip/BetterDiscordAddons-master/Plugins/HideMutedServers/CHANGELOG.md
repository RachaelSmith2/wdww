# HideMutedServers Changelog

### 1.0.1

 - Fix bug where it didn't work
 - Fix bug where it hid muted channels

### 1.0.0

 - First release