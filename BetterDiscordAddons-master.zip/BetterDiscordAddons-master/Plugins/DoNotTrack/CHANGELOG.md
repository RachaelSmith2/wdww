# DoNotTrack Changelog

### 0.0.2

 - Rewrite to new lib

### 0.0.1

 - Initial version