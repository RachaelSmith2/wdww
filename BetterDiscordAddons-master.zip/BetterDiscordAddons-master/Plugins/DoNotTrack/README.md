# DoNotTrack - [Download](https://betterdiscord.app/Download?id=186)

Stops Discord from tracking everything you do like Sentry and Analytics.
