# PermissionsViewer - [Download](https://betterdiscord.app/Download?id=29)

Allows you to view a user's permissions. Thanks to Noodlebox for the idea!

![Preview](https://i.imgur.com/XmHjg4p.png)

Click here for a GIF demo of all features: https://i.imgur.com/lubnuMH.gif

## Features

### Popouts

See a list of all the server permissions a user has in their popout.

### Breakdown

Clicking the details button in the popout or using the context menu will bring up a modal which has a role-by-role breakdown of which roles give what permissions.

## Coming Soon

 - Option to view channel overrides in the modal.

