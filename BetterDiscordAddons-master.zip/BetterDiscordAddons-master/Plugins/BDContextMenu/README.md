# BDContextMenu - [Download](https://betterdiscord.app/Download?id=185)

Adds BD shortcuts to the settings context menu.

## Context Menu

![Context](https://i.imgur.com/ZACEdU6.png)


## More to come soon!


