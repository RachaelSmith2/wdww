# BDContextMenu Changelog

### 0.1.0

 - Use internal patching to hook the menu
 - Use Discord's react menus 
 - Fix loading issues
 - Fix category shortcut issues

### 0.0.15

 - Fix not updating bd settings

### 0.0.14

 - Use native toggles
 - Lexical sorting
 - Context menus no longer use jQuery

### 0.0.11

 - Use the new lib

### 0.0.10

 - Fix a bug where menus wouldn't open

### 0.0.9

 - Switch to new class style
 - Hopefully performance improvement due to memoization

### 0.0.8

 - Hotfix remove observer

### 0.0.7

 - Fix for discord update
 - Use internal classes

### 0.0.6

 - Fuck discord

### 0.0.5

 - Fix for discord update

### 0.0.4

 - I fucked up

### 0.0.3

 - Update to work with Zere's fork

### 0.0.2

 - Add item-group
 - Add submenus to everything
 - Allow enable/disable of plugins, themes, core, and emotes!

### 0.0.1

 - Initial version