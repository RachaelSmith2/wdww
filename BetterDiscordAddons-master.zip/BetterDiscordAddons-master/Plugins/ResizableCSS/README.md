# Discontinued

This is no longer needed as an addon for BD and no longer does anything.

# ResizableCSS

Allows you to resize the detached CustomCSS window. Useful for development and customization.

![Demo](https://thumbs.gfycat.com/PopularLightBluebird-size_restricted.gif)


## Known Bugs and Issues
 - Reloading with inspector open, then detaching custom css and closing inspector can cause odd clipping issues (edge case)
