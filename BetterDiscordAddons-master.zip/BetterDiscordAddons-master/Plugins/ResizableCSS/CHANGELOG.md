# ResizableCSS Changelog

### 0.1.1

 - Swap to a different way for resizing

### 0.0.1

 - Initial Release