# AccountDetailsPlus - [Download](https://betterdiscord.app/Download?id=31)

Lets you view popout, nickname and more from your account panel at the bottom.

## Demo

![Demo](https://i.imgur.com/ZPhgorr.gif)

## Instructions

 - Left click avatar or username for popout
 - Right click avatar or username for status picker
 - Hover to change from nickname to username
 
## Settings

 - Enable/Disable popout for avatar/username
 - Enable/Disable status picker on right click
 - Swap between displaying nickname or username
 - Enable/Disable swapping username and nickname on hover



