# AccountDetailsPlus Changelog

### 0.1.3

 - Fix settings panel

### 0.1.0 

 - Rewrite to new lib

### 0.0.6

 - User popouts aka fuck discord

### 0.0.5

 - Popout fix

### 0.0.4

 - Code cleanup

### 0.0.3

 - Fix for updates
 - Use internal classes

### 0.0.2

 - Fix for discord's refactor

### 0.0.1

 - Initial version