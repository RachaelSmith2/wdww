# ServerSearch Changelog

### 0.1.0

 - Intial rewrite
 - Fix position of popouts

### 0.0.4

 - Adjust classnames

### 0.0.3

 - Fix for discord update
 - Use internal classes

### 0.0.2

 - Update for discord changes

### 0.0.1

 - Initial release