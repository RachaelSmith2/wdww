# ServerSearch - [Download](https://betterdiscord.app/Download?id=192)

Adds a button to search your servers. Search in place or in popout.

## In Place
![InPlace](https://i.imgur.com/F7u4NqG.gif)

## Popout
![Popout](https://i.imgur.com/B5LKYJ4.gif)
