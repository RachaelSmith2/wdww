# AutoPlayGifs - [Download](https://betterdiscord.app/Download?id=441)

Automatically plays avatars, GIFs and GIFVs. (Can be individually turned off in settings)
