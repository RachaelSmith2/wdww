# AutoPlayGifs Changelog

### 0.1.0

 - Rewrite to new lib

### 0.0.5

 - Fixed everything

### 0.0.4

 - Who knows

### 0.0.3

 - Fix bug with missing users in elements

### 0.0.2

 - Remove stuff discord added
 - Add member list avatars

### 0.0.1

 - Initial release