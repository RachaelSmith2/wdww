# HideIconBadge - [Download](https://betterdiscord.app/Download?id=189)

Hides the badge that appears on the taskbar icon.

## From...

![Badge](https://i.imgur.com/DBqBG5B.png)

## To...
![Badgeless](https://i.imgur.com/b3jh72H.png)


