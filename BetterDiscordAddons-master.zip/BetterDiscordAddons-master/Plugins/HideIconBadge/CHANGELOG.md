# HideIconBadge Changelog

### 0.0.4

 - Rewrite to new lib

### 0.0.3

 - Fix for discord update

### 0.0.2

 - Affects the tray as well

### 0.0.1

 - Initial version