# Discontinued

Due to my own time management issues I am starting to offload some of my plugins starting with this one. You can find the new version here: https://betterdiscord.app/plugin/StatusEverywhere

# StatusEverywhere

Adds user status everywhere Discord doesn't.

![Preview](https://i.imgur.com/qqHheT5.png)


