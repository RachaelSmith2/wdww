# HideDisabledEmojis - [Download](https://betterdiscord.app/Download?id=188)

Hides disabled emojis from the emoji picker.


