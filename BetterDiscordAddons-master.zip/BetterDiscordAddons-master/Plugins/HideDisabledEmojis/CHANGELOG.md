# HideDisabledEmojis Changelog

### 0.0.3

 - Rewrite to new lib

### 0.0.2

 - Fix an issue with sticky headers

### 0.0.1

 - Initial version