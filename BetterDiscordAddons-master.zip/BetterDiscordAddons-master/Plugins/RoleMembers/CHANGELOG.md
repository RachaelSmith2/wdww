# RoleMembers Changelog

### 0.1.4

 - Move to patches for mention and context menu

### 0.1.3

 - I'm a failure

### 0.1.2

 - Context menus no longer use jQuery

### 0.1.1

 - Fix context menus sometimes going offscreen

### 0.1.0

 - Rewrite to new lib
 - Fix maligned context menus
 - Fix "roles" not showing in context menu

### 0.0.6

 - User popouts aka fuck discord

### 0.0.5

 - Fix popout render

### 0.0.4

 - Minor performance improvement

### 0.0.3

 - Fix for discord update
 - Use internal classes

### 0.0.2

 - Update for discord changes
 - Add member count to popout
 - Add role colors to context menu
 - Add pseudo-role "@everyone" as an option

### 0.0.1

 - Initial release