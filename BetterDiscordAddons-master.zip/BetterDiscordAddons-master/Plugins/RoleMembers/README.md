# RoleMembers - [Download](https://betterdiscord.app/Download?id=190)

Allows you to see the members of each role on a server. Can also see members from a mention.

## Mention
![Mention](https://i.imgur.com/rGT9Fbl.gif)

## Context Menu
![ContextMenu](https://i.imgur.com/xupyhnD.gif)
