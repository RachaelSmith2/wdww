# ServerSorter Changelog

### 0.4.0

 - Initial rewrite
 - Fixed ordering of multiple options

### 0.3.1

 - Adjust classnames

### 0.3.0

 - Rewrite the sort options as context menu
 - Compatible with server search

### 0.2.4

 - Fix most things

### 0.2.4

 - Update to check for updates
 - New method for grabbing react data
 - Fix bug where it sorted the guild-add button
 - Fix bug where it could prevent discord from loading if you had outaged servers
 - Connected to library

### 0.2.3

 - Add ability to reset the original order
 - Fix a bug where the button wasn't removed on disabling plugin

### 0.2.2

 - Fix some errors with the menu

### 0.2.1

 - More sorting options with react data

### 0.2.0

 - Switch to using a context menu for the sorting options

### 0.1.0

 - Redo a lot of it, adding a menu for the sorting rather than multiple buttons
 - Initial public version

### 0.0.1

 - Initial version