module.exports = {
    C: {cpp: "C++", csharp: "C#", coffeescript: "CoffeeScript", css: "CSS"},
    H: {html: "HTML/XML"},
    J: {java: "Java", js: "JavaScript", json: "JSON"},
    M: {markdown: "Markdown"},
    P: {perl: "Perl", php: "PHP", py: "Python"},
    R: {ruby: "Ruby"},
    S: {sql: "SQL"},
    V: {vbnet: "VB.NET", vhdl: "VHDL"}
};