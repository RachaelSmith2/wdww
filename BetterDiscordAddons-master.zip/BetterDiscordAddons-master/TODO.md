# Bugs
- #237 Fix EmoteSearch
- #186 DNT StopProcessMonitor freezes on active game
- #162 APG pfps dont autoplay if they dont share a mutual server
- Fix Nox
- Fix TransientMaterial


# Enhancements
- #129 TransientMaterial add messages opacity
- #142 BFRedux view raw formatting
- #148 BFRedux backwards text
- #151 BFRedux add quotes
- #158 HideMutedServers Don't count mentions from muted servers
- #168 StatusEverywhere Show mobile status and aria labels
- #203 HideDisabledEmojis Hide emoji preview in chat
- #208 RoleMembers force load offline members
- #242 BlurNSFW Add ability to mark arbitrary channels nsfw
- #254 BFRedux lowercase, uppercase, capitalize

# Other
- Rewrite BFRedux

# Done
- #256 Codeblocks in BFRedux
- #263 EmojiUtilities context menus
- #260 ADP not working
- #245 ADP popouts conflict
- #240 SendButton overlapping other buttons
- #227 PV not consistent with light theme
- #221 PermissionsViewer Add copy role id function