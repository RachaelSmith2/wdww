# [Discontinued] Radial Status

This has been discontinued in favor of the version by Gibbu: https://github.com/Gibbu/BetterDiscord-Themes/tree/master/RadialStatus