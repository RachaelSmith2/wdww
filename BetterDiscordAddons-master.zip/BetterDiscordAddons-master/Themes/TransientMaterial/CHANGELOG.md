# TransientMaterial Changelog

### 1.2.6

 - Change accent to match Nox
 - Fix guild list
 - Fix friend area
 - Change the look of friend area slightly
 - Fix several popouts
 - Fix settings
 - Fix search and search results
 - Fix status picker
 - Fix codeblocks and embeds
 - Fix textarea
 - Improve selectors
 - Fix lots of scrollbars
 - Changes for additional social connections

### 1.2.5

 - Hotpatch for discord changes

### 1.2.4

 - Start changelog (oops)
 - Update for lots of changes in discord
 - Update for lots of changes in beard's theme